﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace P01_StudentSystem.Data
{
    public static class ApplicationCommonConfiguration
    {
        public const string ConnectionString = @"Server=.;Database=StudentSystem;Trusted_Connection=True;";
    }
}
