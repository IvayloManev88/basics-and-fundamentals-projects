﻿namespace MusicHub.Data.Configuration
{
    public static class ConnectionConfiguration
    {
        public static string ConnectionString =
            @"Server=.;Database=MusicHub;Trusted_Connection=True";
    }
}
