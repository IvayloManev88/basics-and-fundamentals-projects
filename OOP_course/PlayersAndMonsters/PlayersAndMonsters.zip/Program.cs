﻿namespace PlayersAndMonsters
{
    public class StartUp
    {
        static void Main()
        {
            DarkKnight dark = new DarkKnight("ivo", 20);
            Console.WriteLine(dark);
        }
    }
}
