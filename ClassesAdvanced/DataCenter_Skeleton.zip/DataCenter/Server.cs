﻿namespace DataCenter
{
    public class Server
    {
       
    }
}
