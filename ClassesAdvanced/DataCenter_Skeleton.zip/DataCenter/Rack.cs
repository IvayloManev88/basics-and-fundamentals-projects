﻿using System.Text;

namespace DataCenter
{
    public class Rack
    {
       
    }
}
