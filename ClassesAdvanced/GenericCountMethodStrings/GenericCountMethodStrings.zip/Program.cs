﻿namespace GenericCountMethodStrings
{
    public class Program
    {
        public static void Main(string[] args)
        {
            int n = int.Parse(Console.ReadLine());
            Box<string> listString = new();
            for (int i = 0; i < n; i++)
            {

                listString.Add(Console.ReadLine());
                

                
            }

            Console.WriteLine(listString.Counter(Console.ReadLine()));
        }
    }
}
