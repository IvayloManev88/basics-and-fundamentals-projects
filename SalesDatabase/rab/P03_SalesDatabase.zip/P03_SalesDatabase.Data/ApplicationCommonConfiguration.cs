﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace P03_SalesDatabase.Data
{
    public class ApplicationCommonConfiguration
        {
        public const string connectionString = @"Server=.;Database=SalesDatabase;Trusted_Connection=True;";
    }
}
